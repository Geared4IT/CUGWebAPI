jQuery(document).ready(function() {
	
	"use strict";
	// Your custom js code goes here.

});